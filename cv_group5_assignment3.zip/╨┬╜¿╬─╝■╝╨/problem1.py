import numpy as np
import os
from PIL import Image


def load_faces(path, ext=".pgm"):
    """Load faces into an array (N, M),
    where N is the number of face images and M is the dimensionality 
    (height*width for greyscale).
    
    Hint: os.walk() supports recursive listing of files 
    and directories in a path
    
    Args:
        path: path to the directory with face images
        ext: extension of the image files (you can assume .pgm only)
    
    Returns:
        x: (N, M) array
        hw: (H, W) tuple
    """
    images = []

    # Use os.walk to walk through the file folder
    for dirpath, _, filenames in os.walk(path):
        for filename in filenames:
            if filename.endswith(ext):
                # Generate the whole path
                image_file_path = os.path.join(dirpath, filename)

                # Read the images.
                img = Image.open(image_file_path).convert('L')
                hw = [img.height, img.width]
                # Add the image into the image array
                img_array = np.array(img).flatten()
                images.append(img_array)
    # Convert the array to numpy array
    x = np.array(images)
    return x, hw


def PCA_mcq():
    """
    Which method will be a more reasonable choice in your implementation
    0: SVD
    1: Eigendecomposition
    Why?
    0: It is more computationally efficient for our problem
    1: It allows to compute eigenvectors and eigenvalues of any matrix
    2: It can be applied to any matrix and is more numerically stable
    3: We can find the eigenvalues we need for our problem from the singular values
    4: We can find the singular values we need for our problem from the eigenvalues

    Return your answer as a tuple, e.g., return (0,0,1) means that the more reasonable
    method is SVD because it is more computationally efficient for our problem, and
    allows to compute eigenvector and eigenvalues of any matrix.
    """
    return [0, 2, 3]


def compute_pca(X):
    """PCA implementation
    
    Args:
        X: (N, M) an array with N M-dimensional features
    
    Returns:
        u: (M, M) bases with principal components
        var: (N,) corresponding variance
    """
    mean_face = np.mean(X, axis=0)
    centered_data = X - mean_face

    # SVD
    U, S, VT = np.linalg.svd(centered_data, full_matrices=False)

    # Calculate explained variance
    var = (S ** 2) / len(X)

    # Compute principal components
    u = VT.T
    return u, var


def basis(u, var, p=0.5):
    """Return the minimum number of basis vectors from matrix U such 
    that they account for at least p percent of total variance.
    
    Hint: Do the singular values really represent the variance?
    
    Args:
        u: (M, M) numpy array containing principal components.
        For example, i'th vector is u[:, i]
        var: (N, ) numpy array containing the variance along the principal components.
        p: percent of total variance that should be contained.
        
    Returns:
        v: (M, D) numpy array that contains M principal components containing at most 
        p (percentile) of the variance.
    
    """
    total_variance = np.sum(var)  # Total variance
    target_variance = p * total_variance  # Target variance

    # Find the minimum number of components needed to reach the target variance
    cumulative_variance = np.cumsum(var)
    num_components = np.argmax(cumulative_variance >= target_variance) + 1

    # Select the corresponding principal components
    v = u[:, :num_components]
    return v


def reconstruct(face_image, mean_face, u):
    """Reconstructs the face image with respect to the first D 
    principal components u.
    
    Args:
        face_image: (M, ) numpy array (M=H*W) of the face.
        mean_face: (M, ) numpy array (M=H*W) mean face.
        u: (M, D) matrix containing D principal components. 
    
    Returns:
        reconstructed_img: (M, ) numpy array of reconstructed face image
    """
    centered_face = face_image - mean_face

    # Calculate the coefficients using the selected principal components
    coefficients = np.dot(centered_face, u)

    # Reconstruct the face image using the coefficients and principal components
    reconstructed_img = mean_face + np.dot(coefficients, u.T)

    return reconstructed_img


def components_mcq():
    """
    Select the right answer (only one option):
    0: The first principal components mostly correspond to local features, e.g., nose, mouth, eyes
    1: The first principal components predominantly contain global structure, e.g., complete face
    2: The fewer principal components we use, the smaller is the re-projection error
    3: The more principal components we use, the sharper is the image
    4: The variations in the last principal components is perceptually insignificant; these bases can be neglected in the projection
    """
    # 1
    return 1


def search(Y, x, u, mean_face, top_n):
    """Search for the top most similar images based on a given number of
    components in their PCA decomposition.
    
    Args:
        Y: (N, M) numpy array with N M-dimensional features
        x: (M, ) numpy array image we would like to retrieve
        u: (M, D) numpy arrray, bases vectors. Note, we already assume D has been selected
        mean_face: (M, ) numpy array, mean face as a vector
        top_n: integer, number of n closest images using L2 distance to return
    
    Returns:
        Y: (top_n, M)
    """
    # Center the input image
    centered_x = x - mean_face

    # Project the input image onto the principal components
    coefficients_x = np.dot(centered_x, u)

    # Project the entire dataset onto the components
    coefficients_Y = np.dot(Y - mean_face, u)

    # Calculate L2 distance between the input image and all images in the dataset
    distances = np.linalg.norm(coefficients_Y - coefficients_x, axis=1)

    # Get indices of top N image
    top_indices = np.argsort(distances)[:top_n]

    # Retrieve the top N most similar images
    Y = Y[top_indices]

    return Y


def interpolate(x1, x2, u, mean_face, n):
    """Interpolates from x1 to x2.
    
    Args:
        x1: (M, ) numpy array, the first image
        x2: (M, ) numpy array, the second image
        u: (M, D) numpy array, bases vectors. Note, we already assume D has been selected.
        mean_face: (M, ) numpy array, mean face as a vector
        n: number of interpolation steps (including x1 and x2)

    Hint: you can use np.linspace to generate N equally-spaced points on a line
    
    Returns:
        Y: (n, M) numpy arrray, interpolated results.
        The first dimension is in the index into corresponding
        image; Y[0] == reconstruct(x1, mean_face, u); Y[-1] == reconstruct(x2, mean_face, u)
    """
    # Project the images onto the selected principal components
    coefficients_x1 = np.dot(x1 - mean_face, u)
    coefficients_x2 = np.dot(x2 - mean_face, u)

    # Interpolate coefficients between x1 and x2
    interpolation_coefficients = np.linspace(coefficients_x1, coefficients_x2, n)

    # Reconstruct the interpolated image
    interpolated_images = []
    for coeff in interpolation_coefficients:
        reconstructed_image = mean_face + np.dot(coeff, u.T)
        interpolated_images.append(reconstructed_image)

    # Convert to numpy array
    Y = np.array(interpolated_images)

    return Y
