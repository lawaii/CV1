import numpy as np
import matplotlib.pyplot as plt


def load_pts_features(path):
    """ Load interest points and SIFT features.

    Args:
        path: path to the file pts_feats.npz
    
    Returns:
        pts: coordinate points for two images;
             an array (2,) of numpy arrays ( 1, 2), (N2, 2)
        feats: SIFT descriptors for two images;
               an array (2,) of numpy arrays (N1, 128), (N2, 128)
    """

    #
    data = np.load(path, allow_pickle=True)
    pts = data['pts']
    feats = data['feats']
    #

    return pts, feats


def min_num_pairs():
    return 4


def pickup_samples(pts1, pts2):
    """ Randomly select k corresponding point pairs.
    Note that here we assume that pts1 and pts2 have 
    been already aligned: pts1[k] corresponds to pts2[k].

    This function makes use of min_num_pairs()

    Args:
        pts1 and pts2: point coordinates from Image 1 and Image 2
    
    Returns:
        pts1_sub and pts2_sub: N_min randomly selected points 
                               from pts1 and pts2
    """

    #
    # use the shorter set in order to avoid index out of bounds
    pair_indices = np.random.choice(min(len(pts1), len(pts2)), min_num_pairs())
    pts1_sub = pts1[pair_indices]
    pts2_sub = pts2[pair_indices]
    #

    return pts1_sub, pts2_sub


def compute_homography(pts1, pts2):
    """ Construct homography matrix and solve it by SVD

    Args:
        pts1: the coordinates of interest points in img1, array (N, 2)
        pts2: the coordinates of interest points in img2, array (M, 2)
    
    Returns:
        H: homography matrix as array (3, 3)
    """

    #
    A = []
    for i in range(min_num_pairs()):
        x, y = pts1[i]
        u, v = pts2[i]
        A.append([-x, -y, -1, 0, 0, 0, x * u, y * u, u])
        A.append([0, 0, 0, -x, -y, -1, x * v, y * v, v])

    A = np.array(A)
    U, S, V_t = np.linalg.svd(A)
    H = V_t[-1].reshape(3,3)
    #

    return H


def transform_pts(pts, H):
    """ Transform pst1 through the homography matrix to compare pts2 to find inliners

    Args:
        pts: interest points in img1, array (N, 2)
        H: homography matrix as array (3, 3)
    
    Returns:
        transformed points, array (N, 2)
    """

    #
    # first transform the coordinates to be homogeneous
    pts_h = np.column_stack((pts, np.ones(pts.shape[0])))
    pts_transformed = np.dot(H, pts_h.T).T
    pts_transformed /= pts_transformed[:, 2, None]
    #

    return pts_transformed[:, :2]


def count_inliers(H, pts1, pts2, threshold=5):
    """ Count inliers
        Tips: We provide the default threshold value, but you're free to test other values
    Args:
        H: homography matrix as array (3, 3)
        pts1: interest points in img1, array (N, 2)
        pts2: interest points in img2, array (N, 2)
        threshold: scale down threshold
    
    Returns:
        number of inliers
    """

    pts1_t = transform_pts(pts1, H)

    distances = np.sqrt(
                    np.sum((pts1_t - pts2) ** 2, axis=1))
    num_inliers = np.sum(distances < threshold)
    return num_inliers


def ransac_iters(w=0.5, d=min_num_pairs(), z=0.99):
    """ Computes the required number of iterations for RANSAC.

    Args:
        w: probability that any given correspondence is valid
        d: minimum number of pairs
        z: total probability of success after all iterations
    
    Returns:
        minimum number of required iterations
    """
    k = np.log(1 - z) / np.log(1 - w ** d)
    return int(np.ceil(k))


def ransac(pts1, pts2):
    """ RANSAC algorithm

    Args:
        pts1: matched points in img1, array (N, 2)
        pts2: matched points in img2, array (N, 2)
    
    Returns:
        best homography observed during RANSAC, array (3, 3)
    """

    #

    # the arguments used, for k and N just use default values
    k = ransac_iters()
    N = min_num_pairs()
    best_inliers = 0
    best_H = np.empty((3,3))

    for i in range(k):
        # each time carry out a single homography matrix calculation
        pts1_selected, pts2_selected = pickup_samples(pts1, pts2)
        H = compute_homography(pts1_selected, pts2_selected)
        num_inliers = count_inliers(H, pts1, pts2)
        # update best H matrix in iterations if better inliers
        if num_inliers > best_inliers:
            best_inliers = num_inliers
            best_H = H
    #
    return best_H


def find_matches(feats1, feats2, rT=0.8):
    """ Find pairs of corresponding interest points with distance comparsion
        Tips: We provide the default ratio value, but you're free to test other values

    Args:
        feats1: SIFT descriptors of interest points in img1, array (N, 128)
        feats2: SIFT descriptors of interest points in img1, array (M, 128)
        rT: Ratio of similar distances
    
    Returns:
        idx1: list of indices of matching points in img1
        idx2: list of indices of matching points in img2
    """

    idx1 = []
    idx2 = []

    #
    for i, des1 in enumerate(feats1):

        # for simplicity first put index on -1 and best distance at -infinitive
        best_idx = -1
        second_best_idx = -1
        best_dis = float('inf')
        second_best_dis = float('inf')

        for j, des2 in enumerate(feats2):
            dis = np.sqrt(np.sum((des1 - des2) ** 2))
            # first judge if it is the new best distance
            if dis < best_dis:
                # iterate first by second best distance
                second_best_dis = best_dis
                second_best_idx = best_idx

                # then best distance
                best_dis = dis
                best_idx = j

            # if not, then judge if it is second best distance
            elif dis < second_best_dis:
                second_best_dis = best_dis
                second_best_idx = j

        # judge if it is less than threshold
        if best_dis / second_best_dis < rT:
            idx1.append(i)
            idx2.append(best_idx)

    #

    return idx1, idx2


def final_homography(pts1, pts2, feats1, feats2):
    """ re-estimate the homography based on all inliers

    Args:
       pts1: the coordinates of interest points in img1, array (N, 2)
       pts2: the coordinates of interest points in img2, array (M, 2)
       feats1: SIFT descriptors of interest points in img1, array (N, 128)
       feats2: SIFT descriptors of interest points in img1, array (M, 128)
    
    Returns:
        ransac_return: refitted homography matrix from ransac fucation, array (3, 3)
        idxs1: list of matched points in image 1
        idxs2: list of matched points in image 2
    """

    #
    idxs1, idxs2 = find_matches(feats1, feats2)
    mpts1 = pts1[idxs1]
    mpts2 = pts2[idxs2]

    # estimate the homography
    ransac_return = ransac(mpts1, mpts2)
    #

    return ransac_return, idxs1, idxs2
